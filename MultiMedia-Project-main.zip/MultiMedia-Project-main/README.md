# MultiMedia-Project
It's about Multi Media in university.

Don't forget about Importing Libraries. You can help from Searching in Google!

For Final Project, you need some "File For Test" that I left it to you :)


Please read the code Carefully to understand what you need to run the code.
